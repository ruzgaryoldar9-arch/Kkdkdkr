package dev.example.donutsmp;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class UtilityScreen extends Screen {
    private boolean coordinatesEnabled = true;
    private boolean chunkInfoEnabled = false;

    public UtilityScreen() {
        super(Text.literal("Client Utilities"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int startY = this.height / 2 - 35;

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Coordinates HUD: " + (coordinatesEnabled ? "ON" : "OFF")),
                button -> {
                    coordinatesEnabled = !coordinatesEnabled;
                    button.setMessage(Text.literal("Coordinates HUD: " + (coordinatesEnabled ? "ON" : "OFF")));
                }).dimensions(centerX - 100, startY, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Chunk Info: " + (chunkInfoEnabled ? "ON" : "OFF")),
                button -> {
                    chunkInfoEnabled = !chunkInfoEnabled;
                    button.setMessage(Text.literal("Chunk Info: " + (chunkInfoEnabled ? "ON" : "OFF")));
                }).dimensions(centerX - 100, startY + 26, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Close"),
                button -> close()).dimensions(centerX - 100, startY + 58, 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 65, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                "Right Shift opens this menu", width / 2, height / 2 + 95, 0xAAAAAA);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
