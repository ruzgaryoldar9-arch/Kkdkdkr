# DonutSMP Client Utilities (Fabric)

Starter source project for Minecraft Java 1.21.11. The menu opens with **Right Shift**.

## Included
- Right Shift keybinding
- Basic client-side menu
- Example toggle controls for local HUD features

This starter does not include server exploitation, hidden-base detection, storage ESP, or bypasses.

## Build
Requires JDK 21 and Gradle 9.x.

From this directory:
```bash
gradle build
```

The output JAR should appear in `build/libs/`.

## Android / PojavLauncher
Build the JAR on a computer or a compatible Android terminal environment, then copy the JAR into the instance's `mods` folder. Install Fabric Loader and a matching Fabric API build for Minecraft 1.21.11.

If dependency resolution fails, verify that the Minecraft, Yarn, Loader, Fabric API, and Loom versions exist in the Fabric Maven repositories and are mutually compatible.

## Automatic GitHub Actions build

1. Upload this project to a GitHub repository.
2. Push the files to the `main` branch, or open **Actions** and run **Build Fabric Mod** with **Run workflow**.
3. Open the completed workflow run.
4. Under **Artifacts**, download `donutsmp-client-mod`. It contains the compiled JAR.
